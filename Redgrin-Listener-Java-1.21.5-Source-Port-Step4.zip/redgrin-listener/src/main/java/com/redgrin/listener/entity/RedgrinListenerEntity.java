package com.redgrin.listener.entity;

import com.redgrin.listener.RedgrinListenerMod;
import com.redgrin.listener.sound.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class RedgrinListenerEntity extends HostileEntity {

    private int digCooldown = 0;
    private int wingCooldown = 0;
    private boolean hasWings = false;
    private boolean isDigging = false;
    private int stunTicksRemaining = 0;

    public RedgrinListenerEntity(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
        this.experiencePoints = 50;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.MAX_HEALTH, 100.0) // "1QD" ~ 100 HP as requested
                .add(EntityAttributes.MOVEMENT_SPEED, 0.28)
                .add(EntityAttributes.ATTACK_DAMAGE, 14.0) // 14 damage = 7 hearts (14 half-hearts)
                .add(EntityAttributes.FOLLOW_RANGE, 48.0)
                .add(EntityAttributes.KNOCKBACK_RESISTANCE, 0.6)
                .add(EntityAttributes.ARMOR, 6.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new MeleeAttackGoal(this, 1.15, false));
        this.goalSelector.add(2, new WanderAroundFarGoal(this, 0.8));
        this.goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 16.0f));
        this.goalSelector.add(4, new LookAroundGoal(this));

        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public void tick() {
        super.tick();

        if (this.getWorld().isClient) return;

        // A stun must always expire; never leave the Listener permanently AI-disabled.
        if (stunTicksRemaining > 0) {
            stunTicksRemaining--;
            if (stunTicksRemaining == 0 && !this.isDead()) {
                this.setAiDisabled(false);
            }
        }

        // Keep to the shadows - prefer low light levels
        if (this.getWorld().getLightLevel(this.getBlockPos()) > 7 && this.age % 40 == 0) {
            // Try to move toward darker areas (simple implementation)
            BlockPos darker = findDarkerNearby();
            if (darker != null) {
                this.getNavigation().startMovingTo(darker.getX(), darker.getY(), darker.getZ(), 1.0);
            }
        }

        // Digging / wall bypass logic stub
        if (digCooldown > 0) digCooldown--;
        if (wingCooldown > 0) wingCooldown--;

        PlayerEntity target = this.getWorld().getClosestPlayer(this, 16.0);
        if (target != null && !this.isDigging && digCooldown <= 0) {
            // If player is building up or placing walls, trigger dig or wings
            // (Full pathfinding / block detection would go here)
        }
    }

    /**
     * Temporarily disables the Listener's AI. The timer is processed on the
     * server tick so the entity is reliably re-enabled after the stun ends.
     */
    public void stunForTicks(int ticks) {
        if (this.getWorld().isClient || ticks <= 0) return;
        stunTicksRemaining = Math.max(stunTicksRemaining, ticks);
        this.setVelocity(0, 0, 0);
        this.setAiDisabled(true);
    }

    private BlockPos findDarkerNearby() {
        BlockPos origin = this.getBlockPos();
        for (int i = 0; i < 12; i++) {
            BlockPos tryPos = origin.add(
                    this.random.nextInt(9) - 4,
                    this.random.nextInt(3) - 1,
                    this.random.nextInt(9) - 4
            );
            if (this.getWorld().getLightLevel(tryPos) < this.getWorld().getLightLevel(origin)) {
                return tryPos;
            }
        }
        return null;
    }

    // Called when player tries to build up high to escape
    public void triggerWings() {
        if (wingCooldown <= 0) {
            this.hasWings = true;
            this.wingCooldown = 200;
            this.playSound(ModSounds.WING_FLAP, 1.0f, 0.8f);
            // Add upward velocity / flying AI here
            this.setVelocity(this.getVelocity().add(0, 0.6, 0));
        }
    }

    // Called when player digs down or places walls
    public void triggerDig() {
        if (digCooldown <= 0) {
            this.isDigging = true;
            this.digCooldown = 160;
            this.playSound(ModSounds.DIG_DRILL, 1.2f, 0.7f);
            // Teleport / path underground then pop up behind player
            // Full implementation needs custom pathfinding
        }
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        // Stake does extra / special damage
        if (source.getAttacker() instanceof PlayerEntity player) {
            if (player.getMainHandStack().isOf(RedgrinListenerMod.STAKE)) {
                amount *= 2.5f; // Strong against him
            }
        }
        return super.damage(source, amount);
    }

    @Override
    public void onDeath(DamageSource damageSource) {
        super.onDeath(damageSource);

        if (!this.getWorld().isClient) {
            // Spawn the bloodshot eyeball that rolls away
            BloodshotEyeballEntity eyeball = new BloodshotEyeballEntity(
                    RedgrinListenerMod.BLOODSHOT_EYEBALL, this.getWorld());
            eyeball.refreshPositionAndAngles(this.getX(), this.getY() + 0.5, this.getZ(), 0, 0);
            this.getWorld().spawnEntity(eyeball);

            this.playSound(ModSounds.DEATH, 1.0f, 0.9f);
            // The eyeball will handle the "I'm always watching" and later teleport logic
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.WHISPER;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_ENDERMAN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 0.9f;
    }

    public boolean hasWings() {
        return hasWings;
    }

    public boolean isDigging() {
        return isDigging;
    }
}
