package com.redgrin.listener.entity;

import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelPartNames;
import net.minecraft.util.math.MathHelper;

/**
 * Custom 3D model for the Redgrin Listener.
 * Tall (~5.4 blocks), hunched posture, long limbs, oversized head with glowing eyes and wide smile.
 * This is a code-based model. For even better results, re-create in Blockbench and export as a Java model.
 */
public class RedgrinListenerModel extends EntityModel<RedgrinListenerEntity> {

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart leftWing;
    private final ModelPart rightWing;

    public RedgrinListenerModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.leftWing = root.getChild("left_wing");
        this.rightWing = root.getChild("right_wing");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();

        // Body - tall and slightly hunched
        root.addChild("body", ModelPartBuilder.create()
                        .uv(0, 16)
                        .cuboid(-4.0f, -18.0f, -3.0f, 8.0f, 18.0f, 6.0f),
                ModelTransform.pivot(0.0f, 6.0f, 0.0f));

        // Head - oversized, pitch black with space for eyes/smile texture
        root.addChild("head", ModelPartBuilder.create()
                        .uv(0, 0)
                        .cuboid(-5.0f, -10.0f, -5.0f, 10.0f, 10.0f, 10.0f)
                        // Glowing eyes (emissive texture layer recommended)
                        .uv(40, 0)
                        .cuboid(-3.5f, -7.0f, -5.1f, 2.0f, 2.0f, 0.2f) // left eye
                        .cuboid(1.5f, -7.0f, -5.1f, 2.0f, 2.0f, 0.2f)  // right eye
                        // Wide white smile
                        .uv(40, 4)
                        .cuboid(-4.0f, -3.5f, -5.2f, 8.0f, 2.0f, 0.3f),
                ModelTransform.pivot(0.0f, -12.0f, 0.0f));

        // Long arms
        root.addChild("left_arm", ModelPartBuilder.create()
                        .uv(32, 16)
                        .cuboid(-1.5f, -2.0f, -2.0f, 3.0f, 16.0f, 4.0f),
                ModelTransform.pivot(5.5f, -10.0f, 0.0f));

        root.addChild("right_arm", ModelPartBuilder.create()
                        .uv(32, 16)
                        .cuboid(-1.5f, -2.0f, -2.0f, 3.0f, 16.0f, 4.0f),
                ModelTransform.pivot(-5.5f, -10.0f, 0.0f));

        // Long legs
        root.addChild("left_leg", ModelPartBuilder.create()
                        .uv(16, 40)
                        .cuboid(-2.0f, 0.0f, -2.0f, 4.0f, 18.0f, 4.0f),
                ModelTransform.pivot(2.0f, 6.0f, 0.0f));

        root.addChild("right_leg", ModelPartBuilder.create()
                        .uv(16, 40)
                        .cuboid(-2.0f, 0.0f, -2.0f, 4.0f, 18.0f, 4.0f),
                ModelTransform.pivot(-2.0f, 6.0f, 0.0f));

        // Wings (hidden until triggered)
        root.addChild("left_wing", ModelPartBuilder.create()
                        .uv(48, 16)
                        .cuboid(0.0f, -4.0f, 0.0f, 12.0f, 10.0f, 1.0f),
                ModelTransform.of(2.0f, -8.0f, 3.0f, 0.0f, 0.4f, 0.3f));

        root.addChild("right_wing", ModelPartBuilder.create()
                        .uv(48, 16)
                        .cuboid(-12.0f, -4.0f, 0.0f, 12.0f, 10.0f, 1.0f),
                ModelTransform.of(-2.0f, -8.0f, 3.0f, 0.0f, -0.4f, -0.3f));

        return TexturedModelData.of(modelData, 64, 64);
    }

    @Override
    public void setAngles(RedgrinListenerEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {

        // Head look
        this.head.yaw = headYaw * ((float) Math.PI / 180f);
        this.head.pitch = headPitch * ((float) Math.PI / 180f);

        // Hunched posture
        this.body.pitch = 0.25f;

        // Walking animation
        float legSwing = MathHelper.cos(limbAngle * 0.6662f) * 1.2f * limbDistance;
        this.leftLeg.pitch = legSwing;
        this.rightLeg.pitch = -legSwing;
        this.leftArm.pitch = -legSwing * 0.7f;
        this.rightArm.pitch = legSwing * 0.7f;

        // Wings only visible / animated when triggered
        boolean wings = entity.hasWings();
        this.leftWing.visible = wings;
        this.rightWing.visible = wings;

        if (wings) {
            float flap = MathHelper.sin(animationProgress * 0.8f) * 0.4f;
            this.leftWing.roll = 0.3f + flap;
            this.rightWing.roll = -0.3f - flap;
        }
    }

    @Override
    public void render(net.minecraft.client.util.math.MatrixStack matrices,
                       net.minecraft.client.render.VertexConsumer vertices,
                       int light, int overlay, float red, float green, float blue, float alpha) {
        root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}
