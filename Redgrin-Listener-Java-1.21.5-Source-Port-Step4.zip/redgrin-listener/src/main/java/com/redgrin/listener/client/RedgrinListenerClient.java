package com.redgrin.listener.client;

import com.redgrin.listener.RedgrinListenerMod;
import com.redgrin.listener.entity.RedgrinListenerModel;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class RedgrinListenerClient implements ClientModInitializer {

    public static final EntityModelLayer MODEL_REDGRIN_LAYER = new EntityModelLayer(
            Identifier.of(RedgrinListenerMod.MOD_ID, "redgrin_listener"), "main");

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(RedgrinListenerMod.REDGRIN_LISTENER, RedgrinListenerRenderer::new);

        EntityModelLayerRegistry.registerModelLayer(MODEL_REDGRIN_LAYER, RedgrinListenerModel::getTexturedModelData);

        // Simple eyeball renderer can be added similarly if desired
        EntityRendererRegistry.register(RedgrinListenerMod.BLOODSHOT_EYEBALL,
                context -> new net.minecraft.client.render.entity.FlyingItemEntityRenderer<>(context));
    }
}
