package com.redgrin.listener.item;

import com.redgrin.listener.entity.RedgrinListenerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.List;

/**
 * Stun Trap - 8 iron ingots around a gold weighted pressure plate.
 * Use it on the ground near the Redgrin Listener to stun him for five seconds.
 * Infinite uses as requested. This is currently an instant-use stun pulse,
 * not yet a persistent floor trap that waits for him to walk over it.
 */
public class StunTrapItem extends Item {

    public StunTrapItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos().up();
        PlayerEntity player = context.getPlayer();

        if (!world.isClient && player != null) {
            // Place a temporary "trap zone" effect
            // In a full version you would spawn a block entity or marker entity
            world.playSound(null, pos, SoundEvents.BLOCK_IRON_TRAPDOOR_CLOSE, SoundCategory.BLOCKS, 1.0f, 0.8f);

            // Check for nearby Listener and stun
            Box area = new Box(pos).expand(2.5);
            List<RedgrinListenerEntity> listeners = world.getEntitiesByClass(
                    RedgrinListenerEntity.class, area, e -> true);

            for (RedgrinListenerEntity listener : listeners) {
                // Disable its AI for five seconds; the entity owns the timer
                // and safely re-enables itself when the stun expires.
                listener.stunForTicks(100);
            }

            player.sendMessage(Text.literal("Stun trap armed.").formatted(Formatting.GREEN), true);
        }

        return ActionResult.success(world.isClient);
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, net.minecraft.client.item.TooltipContext context) {
        tooltip.add(Text.literal("Use near the Listener to stun him for 5 seconds.").formatted(Formatting.GRAY));
        tooltip.add(Text.literal("Infinite uses.").formatted(Formatting.DARK_GREEN));
        super.appendTooltip(stack, world, tooltip, context);
    }
}
