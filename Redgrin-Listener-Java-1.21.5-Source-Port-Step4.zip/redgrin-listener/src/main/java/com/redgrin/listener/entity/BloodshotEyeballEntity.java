package com.redgrin.listener.entity;

import com.redgrin.listener.sound.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class BloodshotEyeballEntity extends PathAwareEntity {

    private int lifeTicks = 0;
    private static final int STALK_DURATION = 20 * 60 * 10; // 10 real minutes
    private boolean hasSpoken = false;
    private boolean hasFinished = false;

    public BloodshotEyeballEntity(EntityType<? extends PathAwareEntity> entityType, World world) {
        super(entityType, world);
        this.setNoGravity(false);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return PathAwareEntity.createMobAttributes()
                .add(EntityAttributes.MAX_HEALTH, 20.0)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.18)
                .add(EntityAttributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    public void tick() {
        super.tick();
        lifeTicks++;

        if (this.getWorld().isClient) return;

        // Roll away slowly at first
        if (lifeTicks < 60) {
            Vec3d vel = this.getVelocity();
            this.setVelocity(vel.x * 0.95 + (random.nextDouble() - 0.5) * 0.05,
                    vel.y,
                    vel.z * 0.95 + (random.nextDouble() - 0.5) * 0.05);
        }

        // Speak once
        if (!hasSpoken && lifeTicks > 40) {
            this.playSound(ModSounds.ALWAYS_WATCHING, 1.0f, 1.0f);
            for (PlayerEntity p : this.getWorld().getPlayers()) {
                if (p.squaredDistanceTo(this) < 1024) {
                    p.sendMessage(Text.literal("§cI'm always watching..."), false);
                }
            }
            hasSpoken = true;
        }

        // After 10 minutes of real-time stalking, allow approach then teleport
        if (lifeTicks >= STALK_DURATION && !hasFinished) {
            PlayerEntity nearest = this.getWorld().getClosestPlayer(this, 8.0);
            if (nearest != null && nearest.squaredDistanceTo(this) < 9.0) { // within ~3 blocks
                // Teleport player back to a blacksmith-like position (spawn village blacksmith approximation)
                if (nearest instanceof ServerPlayerEntity serverPlayer) {
                    // Simple: teleport near original spawn or a fixed relative point
                    // In a full mod you would store the original blacksmith position
                    BlockPos target = serverPlayer.getWorld().getSpawnPos();
                    serverPlayer.teleport((ServerWorld) this.getWorld(),
                            target.getX() + 0.5, target.getY(), target.getZ() + 0.5,
                            serverPlayer.getYaw(), serverPlayer.getPitch());

                    serverPlayer.sendMessage(Text.literal("§4You spy the eyeball through the window of the blacksmith house..."), false);
                    this.playSound(ModSounds.WORK_DONE, 1.0f, 0.85f);
                    serverPlayer.sendMessage(Text.literal("§7My work is done."), false);

                    // After this the world returns to "normal" - remove entity
                    this.discard();
                    hasFinished = true;
                }
            }
        }

        // Slow random rolling / stalking movement
        if (lifeTicks % 30 == 0 && lifeTicks < STALK_DURATION) {
            PlayerEntity p = this.getWorld().getClosestPlayer(this, 24.0);
            if (p != null) {
                this.getNavigation().startMovingTo(p, 0.7);
            }
        }
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("LifeTicks", lifeTicks);
        nbt.putBoolean("HasSpoken", hasSpoken);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        lifeTicks = nbt.getInt("LifeTicks");
        hasSpoken = nbt.getBoolean("HasSpoken");
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void pushAway(net.minecraft.entity.Entity entity) {
        // Doesn't get pushed easily
    }
}
