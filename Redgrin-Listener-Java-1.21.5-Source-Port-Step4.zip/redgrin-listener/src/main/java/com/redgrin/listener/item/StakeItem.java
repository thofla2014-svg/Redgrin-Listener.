package com.redgrin.listener.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;

/**
 * The stake - crafted with 3 iron ingots vertically.
 * Does heavy damage to the Redgrin Listener ("1QD" style damage).
 */
public class StakeItem extends SwordItem {

    public StakeItem(Item.Settings settings) {
        super(ToolMaterials.IRON, 8, -2.4f, settings); // High damage
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        // Extra effect against the Listener is handled in the entity's damage method
        return super.postHit(stack, target, attacker);
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, net.minecraft.client.item.TooltipContext context) {
        tooltip.add(Text.literal("A crude iron stake.").formatted(Formatting.GRAY));
        tooltip.add(Text.literal("Especially effective against the Listener.").formatted(Formatting.DARK_RED));
        super.appendTooltip(stack, world, tooltip, context);
    }
}
