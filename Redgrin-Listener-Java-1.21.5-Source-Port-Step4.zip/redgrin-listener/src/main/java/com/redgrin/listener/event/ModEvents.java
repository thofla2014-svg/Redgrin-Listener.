package com.redgrin.listener.event;

import com.redgrin.listener.RedgrinListenerMod;
import com.redgrin.listener.entity.RedgrinListenerEntity;
import com.redgrin.listener.sound.ModSounds;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

/**
 * Handles the special spawn sequence when entering a blacksmith house.
 * Simplified version - detects interaction near a smithing table / lava / iron bars style setup.
 */
public class ModEvents {

    private static boolean hasTriggered = false; // Simple one-time flag per server session
    private static final List<PendingSpawn> PENDING_SPAWNS = new ArrayList<>();

    private static final class PendingSpawn {
        private final ServerWorld world;
        private final PlayerEntity player;
        private final BlockPos pos;
        private int ticksRemaining;

        private PendingSpawn(ServerWorld world, PlayerEntity player, BlockPos pos, int delayTicks) {
            this.world = world;
            this.player = player;
            this.pos = pos.toImmutable();
            this.ticksRemaining = delayTicks;
        }
    }

    public static void register() {
        // Run delayed actions on the server thread; never sleep/block the game server.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Iterator<PendingSpawn> iterator = PENDING_SPAWNS.iterator();
            while (iterator.hasNext()) {
                PendingSpawn pending = iterator.next();
                if (--pending.ticksRemaining > 0) continue;
                iterator.remove();
                if (pending.player.isRemoved() || !pending.world.isChunkLoaded(pending.pos)) continue;

                RedgrinListenerEntity listener = new RedgrinListenerEntity(
                        RedgrinListenerMod.REDGRIN_LISTENER, pending.world);
                listener.refreshPositionAndAngles(
                        pending.pos.getX() + 2.0, pending.pos.getY(), pending.pos.getZ() + 2.0,
                        pending.player.getYaw() + 180, 0);
                pending.world.spawnEntity(listener);

                pending.player.sendMessage(Text.literal("I'm listening...").formatted(Formatting.DARK_RED), false);
                pending.world.playSound(null, pending.player.getBlockPos(), ModSounds.WHISPER,
                        SoundCategory.MASTER, 1.0f, 0.85f);
            }
        });

        // Example trigger: right-click a smithing table or blast furnace in a village context
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.isClient || hasTriggered) return ActionResult.PASS;

            BlockPos pos = hitResult.getBlockPos();
            if (world.getBlockState(pos).isOf(Blocks.SMITHING_TABLE) ||
                world.getBlockState(pos).isOf(Blocks.BLAST_FURNACE) ||
                world.getBlockState(pos).isOf(Blocks.ANVIL)) {

                // Rough check if we are in a village-like area (lots of doors, etc. would be better)
                // For demo: just trigger once near these blocks
                triggerSequence(player, (ServerWorld) world, pos);
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });
    }

    private static void triggerSequence(PlayerEntity player, ServerWorld world, BlockPos pos) {
        hasTriggered = true;
        player.sendMessage(Text.literal("The floor feels unstable...").formatted(Formatting.DARK_GRAY), false);
        world.playSound(null, pos, ModSounds.WHISPER, SoundCategory.AMBIENT, 0.7f, 0.6f);

        // 50 server ticks = 2.5 seconds at 20 ticks per second.
        PENDING_SPAWNS.add(new PendingSpawn(world, player, pos, 50));
    }
}
