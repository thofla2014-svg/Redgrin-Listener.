package com.redgrin.listener.sound;

import com.redgrin.listener.RedgrinListenerMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {

    public static final SoundEvent WHISPER = register("whisper");
    public static final SoundEvent DIG_DRILL = register("dig_drill");
    public static final SoundEvent WING_FLAP = register("wing_flap");
    public static final SoundEvent DEATH = register("death");
    public static final SoundEvent ALWAYS_WATCHING = register("always_watching");
    public static final SoundEvent WORK_DONE = register("work_done");

    private static SoundEvent register(String name) {
        Identifier id = Identifier.of(RedgrinListenerMod.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void register() {
        // Just forces static init
        RedgrinListenerMod.LOGGER.info("Registered Redgrin Listener sounds");
    }
}
