package com.redgrin.listener.client;

import com.redgrin.listener.RedgrinListenerMod;
import com.redgrin.listener.entity.RedgrinListenerEntity;
import com.redgrin.listener.entity.RedgrinListenerModel;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class RedgrinListenerRenderer extends MobEntityRenderer<RedgrinListenerEntity, RedgrinListenerModel> {

    private static final Identifier TEXTURE = Identifier.of(RedgrinListenerMod.MOD_ID, "textures/entity/redgrin_listener.png");

    public RedgrinListenerRenderer(EntityRendererFactory.Context context) {
        super(context, new RedgrinListenerModel(context.getPart(RedgrinListenerClient.MODEL_REDGRIN_LAYER)), 0.8f);
    }

    @Override
    public Identifier getTexture(RedgrinListenerEntity entity) {
        return TEXTURE;
    }
}
